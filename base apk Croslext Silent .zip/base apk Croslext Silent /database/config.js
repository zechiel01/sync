module.exports = {
  tokens: "8330472404:AAHkdneYASMdTZuCEv7-aGKLAvJa57W5OmM",  // Masukin Bot token kamu
  owners: "1007189444", // Masukin ID Telegram kamu
  port: "2086", // Masukin Port panel kamu 
  ipvps: "139.59.100.155" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};